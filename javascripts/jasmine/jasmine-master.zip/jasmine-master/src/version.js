
jasmine.version_= {
  "major": 1,
  "minor": 3,
  "build": 1,
  "revision": 1354556913
};
